<?php
    $bdd = new PDO('mysql:host=localhost;dbname=test','root','');

    $req = $bdd->query("select Id, Matricule, Nom, Prenom, Sexe, Email from utilisateurs");
    $users = $req->fetchAll(PDO::FETCH_ASSOC);

    $tablehead = ["Id","Matricule","Nom","Prénom","Sexe","Email","Action 1","Action 2"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Affichage</title>
    <link rel="stylesheet" href="../assets/bootstrap.min.css">
</head>
<body>

<table class="table table-striped">
    <thead>
        <?php

            foreach($tablehead as $element) {
                echo "<td>$element</td>";
            }

        ?>
       
    </thead>
    <tbody>
        <?php
            foreach ($users as $user) { ?>
            <tr>
                <?php
                    foreach($user as $info) { ?>
                    <td><?= $info ?></td>
                <?php
                 }     
                ?>
                <td><button class="btn btn-primary">Modifier</button></td>
                <td><button class="btn btn-danger">Supprimer</button></td>
            </tr>
       <?php
            }
        ?>
    </tbody>
</table>

</body>
</html>
